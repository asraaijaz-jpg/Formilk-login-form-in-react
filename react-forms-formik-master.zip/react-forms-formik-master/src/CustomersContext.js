import React from "react";

const CustomersContext = React.createContext([]);

export default CustomersContext;
